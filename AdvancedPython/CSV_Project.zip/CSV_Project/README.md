# matplotlib_csv
Advanced Python - Matplotlib - using CSV files

this project is to teach students how to use CSV files in python
this project also teaches students how to visualize the data using matplotlib

