import json

in_file = open("US_fires_9_14.json")
out_file = open("readable_fires_2.json", "w")

fire_data = json.load(in_file)

print(type(fire_data))

json.dump(fire_data, out_file, indent=4)

list_of_fires = fire_data

brights, lons, lats = [], [], []

for fire in list_of_fires:
    bright = fire["brightness"]
    lon = fire["longitude"]
    lat = fire["latitude"]
    if bright > 450
        brights.append(bright)
        lons.append(lon)
        lats.append(lat)

from plotly.graph_objs import Scattergeo, Layout
from plotly import offline

data = [
    {
        "type": "scattergeo",
        "lon": lons,
        "lat": lats,
    }
]

my_layout = Layout(title="US Fires")

fig = {"data": data, "layout": my_layout}

offline.plot(fig, filename="US_fires.html")
